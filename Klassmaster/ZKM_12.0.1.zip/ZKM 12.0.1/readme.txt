==============================
Zelix KlassMaster version 12.0 
==============================


License.
========

The license governing your use of Zelix KlassMaster is contained in the
file license.html.


Documentation.
==============

Basic installation instructions are contained in the file install.html.
The full Zelix KlassMaster HTML documentation can be 
   * viewed online at http://www.zelix.com/klassmaster/docs/index.html.
   * downloaded at http://www.zelix.com/klassmaster/download1.html.

In particular, see the Getting Started documentation at
http://www.zelix.com/klassmaster/docs/gettingStarted.html .
